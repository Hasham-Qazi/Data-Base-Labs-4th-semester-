-- ============================================================================
--  CarGo Rentals - Car Rental Management System
--  DBMS Open-Ended Lab
--  Target RDBMS : MySQL 8.0+ (uses DELIMITER, TRIGGERS, STORED PROCEDURES,
--                  CHECK constraints, VIEWS)
--  Author       : Student Submission
-- ============================================================================
-- HOW TO RUN
--   mysql -u root -p < CarGo_Rentals_DBMS.sql
-- ============================================================================


-- ============================================================================
-- 0. DATABASE SETUP
-- ============================================================================
DROP DATABASE IF EXISTS CarGoRentals;
CREATE DATABASE CarGoRentals;
USE CarGoRentals;


-- ============================================================================
-- TASK 1 : DATABASE DESIGN AND IMPLEMENTATION
-- ============================================================================
-- Design justification (see report for full discussion):
--   Customers        -> one row per customer, contact details unique per person
--   Vehicles         -> one row per vehicle, tracks live availability Status
--   Rentals          -> one row per rental transaction, links Customers<->Vehicles
--   Payments         -> one row per payment, linked 1-to-1 with a Rental
--
--   A vehicle cannot be double-booked because:
--     (a) Vehicles.Status is maintained as 'Available' / 'Rented' / 'Maintenance'
--     (b) a BEFORE INSERT trigger on Rentals rejects a new rental if the
--         vehicle's current Status is not 'Available'
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1.1 CUSTOMERS
-- ----------------------------------------------------------------------------
CREATE TABLE Customers (
    CustomerID      INT AUTO_INCREMENT PRIMARY KEY,
    FullName        VARCHAR(100)    NOT NULL,
    Phone           VARCHAR(20)     NOT NULL UNIQUE,
    Email           VARCHAR(100)    UNIQUE,
    LicenseNumber   VARCHAR(30)     NOT NULL UNIQUE,
    Address         VARCHAR(150),
    RegisteredOn    DATE            NOT NULL DEFAULT (CURRENT_DATE)
);

-- ----------------------------------------------------------------------------
-- 1.2 VEHICLES
-- ----------------------------------------------------------------------------
CREATE TABLE Vehicles (
    VehicleID       INT AUTO_INCREMENT PRIMARY KEY,
    VehicleNumber   VARCHAR(15)     NOT NULL UNIQUE,
    Make            VARCHAR(50)     NOT NULL,
    Model           VARCHAR(50)     NOT NULL,
    ManufactureYear INT             NOT NULL CHECK (ManufactureYear BETWEEN 1990 AND 2030),
    DailyRate       DECIMAL(10,2)   NOT NULL CHECK (DailyRate > 0),
    Status          VARCHAR(15)     NOT NULL DEFAULT 'Available'
                        CHECK (Status IN ('Available','Rented','Maintenance'))
);

-- ----------------------------------------------------------------------------
-- 1.3 RENTALS
-- ----------------------------------------------------------------------------
CREATE TABLE Rentals (
    RentalID          INT AUTO_INCREMENT PRIMARY KEY,
    CustomerID        INT             NOT NULL,
    VehicleID         INT             NOT NULL,
    RentalDate        DATE            NOT NULL,
    ExpectedReturnDate DATE           NOT NULL,
    ActualReturnDate  DATE            NULL,
    RentalStatus      VARCHAR(15)     NOT NULL DEFAULT 'Active'
                          CHECK (RentalStatus IN ('Active','Completed','Cancelled')),
    TotalAmount       DECIMAL(10,2)   NULL CHECK (TotalAmount IS NULL OR TotalAmount >= 0),

    CONSTRAINT fk_rentals_customer FOREIGN KEY (CustomerID)
        REFERENCES Customers(CustomerID)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_rentals_vehicle FOREIGN KEY (VehicleID)
        REFERENCES Vehicles(VehicleID)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_rental_dates CHECK (ExpectedReturnDate >= RentalDate)
);

-- Foreign-key columns are indexed to speed up the JOIN queries in Task 3
-- (see Task 7 - Optimization Analysis for the reasoning)
CREATE INDEX idx_rentals_customer ON Rentals(CustomerID);
CREATE INDEX idx_rentals_vehicle  ON Rentals(VehicleID);

-- ----------------------------------------------------------------------------
-- 1.4 PAYMENTS
-- ----------------------------------------------------------------------------
CREATE TABLE Payments (
    PaymentID       INT AUTO_INCREMENT PRIMARY KEY,
    RentalID        INT             NOT NULL UNIQUE,   -- 1-to-1 with Rentals
    Amount          DECIMAL(10,2)   NOT NULL CHECK (Amount >= 0),
    PaymentDate     DATE            NOT NULL,
    PaymentMethod   VARCHAR(20)     NOT NULL DEFAULT 'Cash'
                        CHECK (PaymentMethod IN ('Cash','Card','Online')),

    CONSTRAINT fk_payments_rental FOREIGN KEY (RentalID)
        REFERENCES Rentals(RentalID)
        ON DELETE CASCADE ON UPDATE CASCADE
);


-- ============================================================================
-- 1.5 SAMPLE DATA
-- ============================================================================

INSERT INTO Customers (FullName, Phone, Email, LicenseNumber, Address) VALUES
('Ali Khan',        '0300-1234567', 'ali.khan@example.com',    'LIC-1001', 'Gulberg, Lahore'),
('Sara Ahmed',      '0301-2345678', 'sara.ahmed@example.com',  'LIC-1002', 'DHA, Karachi'),
('Bilal Hussain',   '0302-3456789', 'bilal.h@example.com',     'LIC-1003', 'F-10, Islamabad'),
('Ayesha Tariq',    '0303-4567890', 'ayesha.t@example.com',    'LIC-1004', 'Model Town, Lahore'),
('Usman Farooq',    '0304-5678901', 'usman.f@example.com',     'LIC-1005', 'Clifton, Karachi'),
('Hina Riaz',       '0305-6789012', 'hina.riaz@example.com',   'LIC-1006', 'G-9, Islamabad');
-- Note: Hina Riaz is intentionally never used in a rental below,
-- to demonstrate LEFT JOIN behaviour in Task 3.

-- NOTE: LEB-456 and ISB-654 are inserted directly as 'Rented' because the
-- sample data below immediately places them into ACTIVE rentals. In normal
-- day-to-day use the Status column is never set by hand - it is
-- flipped automatically by trg_rentals_after_insert / trg_rentals_after_update
-- (Task 5) whenever a rental is created or completed through the
-- application / sp_RegisterRental procedure (Task 6).
INSERT INTO Vehicles (VehicleNumber, Make, Model, ManufactureYear, DailyRate, Status) VALUES
('ABC-123', 'Toyota',   'Corolla',  2022, 5000.00, 'Available'),
('LEB-456', 'Honda',    'Civic',    2021, 5500.00, 'Rented'),
('LEA-789', 'Suzuki',   'Cultus',   2023, 3500.00, 'Available'),
('KHI-321', 'Toyota',   'Yaris',    2022, 4500.00, 'Available'),
('ISB-654', 'Honda',    'City',     2020, 4800.00, 'Rented'),
('LEC-987', 'Toyota',   'Fortuner', 2023, 9000.00, 'Available');
-- KHI-321 is intentionally kept idle (never rented) to demonstrate
-- LEFT JOIN behaviour for "vehicles currently not rented" in Task 3,
-- and is later used to demonstrate sp_RegisterRental in Task 6.

-- NOTE: these five rows are historical/backfilled data (loaded once while
-- setting up the system), so they are inserted directly with TotalAmount
-- already known. From this point forward, all NEW rentals should be created
-- through sp_RegisterRental (Task 6), which calculates TotalAmount
-- automatically and is demonstrated later in this script.

-- Completed rental: RentalID 1, 3 days @ 5000/day = 15000
INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate, ActualReturnDate, RentalStatus, TotalAmount)
VALUES (1, 1, '2026-09-01', '2026-09-04', '2026-09-04', 'Completed', 15000.00);

-- Completed rental: RentalID 2, 2 days @ 3500/day = 7000
INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate, ActualReturnDate, RentalStatus, TotalAmount)
VALUES (2, 3, '2026-09-05', '2026-09-07', '2026-09-07', 'Completed', 7000.00);

-- Active rental: RentalID 3 (still out, vehicle LEB-456 already marked 'Rented' above)
INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate)
VALUES (3, 2, '2026-09-15', '2026-09-20');

-- Active rental: RentalID 4 (still out, vehicle ISB-654 already marked 'Rented' above)
INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate)
VALUES (1, 5, '2026-09-18', '2026-09-22');

-- Completed rental for a different customer: RentalID 5, 2 days @ 9000/day = 18000
INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate, ActualReturnDate, RentalStatus, TotalAmount)
VALUES (4, 6, '2026-08-10', '2026-08-12', '2026-08-12', 'Completed', 18000.00);

-- Payments for the three completed rentals above (active rentals 3 & 4 are
-- not yet paid because the car has not been returned yet)
INSERT INTO Payments (RentalID, Amount, PaymentDate, PaymentMethod) VALUES
(1, 15000.00, '2026-09-04', 'Cash'),      -- RentalID 1: 3 days * 5000
(2, 7000.00,  '2026-09-07', 'Card'),      -- RentalID 2: 2 days * 3500
(5, 18000.00, '2026-08-12', 'Online');    -- RentalID 5: 2 days * 9000


-- ============================================================================
-- TASK 2 : NORMALIZATION  (1NF -> 2NF -> 3NF)
-- ============================================================================
-- The full written explanation is provided in the accompanying report.
-- The statements below are illustrative of the DECOMPOSITION described there,
-- starting from the single unnormalized table given in the assignment:
--
--   UNF/1NF-violating table:
--   RentalRaw(RentalID, CustomerName, CustomerPhone, VehicleNumber,
--             VehicleModel, DailyRate, RentalDate, ReturnDate, PaymentAmount)
--
-- Demonstration table representing the ORIGINAL unnormalized structure:
CREATE TABLE RentalRaw_UNF (
    RentalID        INT,
    CustomerName    VARCHAR(100),
    CustomerPhone   VARCHAR(20),
    VehicleNumber   VARCHAR(15),
    VehicleModel    VARCHAR(50),
    DailyRate       DECIMAL(10,2),
    RentalDate      DATE,
    ReturnDate      DATE,
    PaymentAmount   DECIMAL(10,2)
);

INSERT INTO RentalRaw_UNF VALUES
(1,'Ali Khan','0300-1234567','ABC-123','Toyota Corolla',5000.00,'2026-09-01','2026-09-04',15000.00);

-- 1NF: table above already has atomic columns and no repeating groups,
-- so RentalRaw_UNF IS the 1NF version (all values atomic, single-valued cells).
-- We simply rename it conceptually to RentalRaw_1NF (same structure).

-- 2NF: remove partial dependencies by splitting repeating customer/vehicle
-- attributes into their own tables, keyed on values that determine them
-- (this mirrors the Customers / Vehicles tables created in Task 1):
CREATE TABLE Demo_Customer_2NF (
    CustomerPhone   VARCHAR(20) PRIMARY KEY,
    CustomerName    VARCHAR(100) NOT NULL
);
CREATE TABLE Demo_Vehicle_2NF (
    VehicleNumber   VARCHAR(15) PRIMARY KEY,
    VehicleModel    VARCHAR(50) NOT NULL,
    DailyRate       DECIMAL(10,2) NOT NULL
);
CREATE TABLE Demo_Rental_2NF (
    RentalID        INT PRIMARY KEY,
    CustomerPhone   VARCHAR(20) NOT NULL REFERENCES Demo_Customer_2NF(CustomerPhone),
    VehicleNumber   VARCHAR(15) NOT NULL REFERENCES Demo_Vehicle_2NF(VehicleNumber),
    RentalDate      DATE,
    ReturnDate      DATE,
    PaymentAmount   DECIMAL(10,2)
);

-- 3NF: remove the transitive dependency DailyRate -> PaymentAmount
-- (PaymentAmount is computed FROM DailyRate and the rental period, it is not
--  an independent fact about the rental) by dropping PaymentAmount from the
--  rental table and deriving it, or storing it in its own Payments entity
--  (exactly as Payments is separated from Rentals in the final Task 1 schema):
CREATE TABLE Demo_Rental_3NF (
    RentalID        INT PRIMARY KEY,
    CustomerPhone   VARCHAR(20) NOT NULL REFERENCES Demo_Customer_2NF(CustomerPhone),
    VehicleNumber   VARCHAR(15) NOT NULL REFERENCES Demo_Vehicle_2NF(VehicleNumber),
    RentalDate      DATE,
    ReturnDate      DATE
);
CREATE TABLE Demo_Payment_3NF (
    PaymentID       INT AUTO_INCREMENT PRIMARY KEY,
    RentalID        INT NOT NULL REFERENCES Demo_Rental_3NF(RentalID),
    PaymentAmount   DECIMAL(10,2)
);
-- The final Task 1 schema (Customers, Vehicles, Rentals, Payments) IS this
-- 3NF design, extended with proper surrogate keys, constraints and status
-- tracking columns needed for the business rules of the system.


-- ============================================================================
-- TASK 3 : JOIN QUERIES
-- ============================================================================

-- --------------------------------------------------------------------------
-- Q1. Customer name, vehicle number, vehicle model, rental date, return date
--     for EVERY rental.
-- --------------------------------------------------------------------------
SELECT
    c.FullName          AS CustomerName,
    v.VehicleNumber,
    v.Model              AS VehicleModel,
    r.RentalDate,
    r.ActualReturnDate   AS ReturnDate
FROM Rentals r
INNER JOIN Customers c ON r.CustomerID = c.CustomerID
INNER JOIN Vehicles  v ON r.VehicleID  = v.VehicleID
ORDER BY r.RentalDate;

-- --------------------------------------------------------------------------
-- Q2. All customers and the vehicles they have rented; customers who have
--     never rented a vehicle should also appear (LEFT JOIN from Customers).
-- --------------------------------------------------------------------------
SELECT
    c.FullName          AS CustomerName,
    v.VehicleNumber,
    v.Model              AS VehicleModel,
    r.RentalDate
FROM Customers c
LEFT JOIN Rentals r  ON c.CustomerID = r.CustomerID
LEFT JOIN Vehicles v ON r.VehicleID  = v.VehicleID
ORDER BY c.FullName;

-- --------------------------------------------------------------------------
-- Q3. All vehicles and their CURRENT rental information; vehicles that are
--     currently not rented should also appear (LEFT JOIN from Vehicles,
--     restricted to Active rentals only).
-- --------------------------------------------------------------------------
SELECT
    v.VehicleNumber,
    v.Model               AS VehicleModel,
    v.Status               AS VehicleStatus,
    c.FullName             AS CurrentRenter,
    r.RentalDate,
    r.ExpectedReturnDate
FROM Vehicles v
LEFT JOIN Rentals r
       ON v.VehicleID = r.VehicleID AND r.RentalStatus = 'Active'
LEFT JOIN Customers c ON r.CustomerID = c.CustomerID
ORDER BY v.VehicleNumber;

-- --------------------------------------------------------------------------
-- Q4. Total number of rentals made by each customer, INCLUDING customers
--     who have made no rentals (LEFT JOIN + COUNT).
-- --------------------------------------------------------------------------
SELECT
    c.CustomerID,
    c.FullName            AS CustomerName,
    COUNT(r.RentalID)     AS TotalRentals
FROM Customers c
LEFT JOIN Rentals r ON c.CustomerID = r.CustomerID
GROUP BY c.CustomerID, c.FullName
ORDER BY TotalRentals DESC;


-- ============================================================================
-- TASK 4 : VIEW
-- ============================================================================
-- vw_RentalReport gives management a single, ready-to-query consolidated
-- report of every rental with customer, vehicle and payment details, without
-- needing to repeat the 3-way / 4-way JOIN every time a report is required.
CREATE OR REPLACE VIEW vw_RentalReport AS
SELECT
    r.RentalID,
    c.FullName               AS CustomerName,
    c.Phone                  AS CustomerPhone,
    v.VehicleNumber,
    v.Make,
    v.Model,
    r.RentalDate,
    r.ExpectedReturnDate,
    r.ActualReturnDate,
    r.RentalStatus,
    r.TotalAmount,
    p.PaymentDate,
    p.PaymentMethod,
    p.Amount                 AS AmountPaid
FROM Rentals r
JOIN Customers c        ON r.CustomerID = c.CustomerID
JOIN Vehicles  v        ON r.VehicleID  = v.VehicleID
LEFT JOIN Payments p    ON r.RentalID   = p.RentalID;

-- Demonstration:
SELECT * FROM vw_RentalReport ORDER BY RentalDate;


-- ============================================================================
-- TASK 5 : TRIGGERS
-- ============================================================================
-- Business rule from the scenario:
-- "A vehicle should not be available for another rental while it is
--  already rented."
--
-- trg_rentals_before_insert : rejects a new rental if the vehicle is not
--                              currently 'Available'.
-- trg_rentals_after_insert  : marks the vehicle as 'Rented' once a rental
--                              is successfully created, and auto-calculates
--                              TotalAmount when the rental is created with
--                              dates already known.
-- trg_rentals_after_update  : when a rental is completed (ActualReturnDate
--                              is set / RentalStatus -> 'Completed'), the
--                              vehicle is automatically freed up again and
--                              TotalAmount is (re)calculated.
-- ============================================================================

DELIMITER $$

CREATE TRIGGER trg_rentals_before_insert
BEFORE INSERT ON Rentals
FOR EACH ROW
BEGIN
    DECLARE v_status VARCHAR(15);

    SELECT Status INTO v_status FROM Vehicles WHERE VehicleID = NEW.VehicleID;

    IF v_status IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Vehicle does not exist.';
    ELSEIF v_status <> 'Available' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'This vehicle is already rented / unavailable.';
    END IF;
END$$

CREATE TRIGGER trg_rentals_after_insert
AFTER INSERT ON Rentals
FOR EACH ROW
BEGIN
    UPDATE Vehicles
       SET Status = 'Rented'
     WHERE VehicleID = NEW.VehicleID;
END$$

CREATE TRIGGER trg_rentals_after_update
AFTER UPDATE ON Rentals
FOR EACH ROW
BEGIN
    IF NEW.RentalStatus = 'Completed' AND OLD.RentalStatus <> 'Completed' THEN
        UPDATE Vehicles
           SET Status = 'Available'
         WHERE VehicleID = NEW.VehicleID;
    END IF;
END$$

DELIMITER ;

-- Trigger demonstration / test:
-- This should FAIL because VehicleID 2 (LEB-456) is currently 'Rented'
-- (uncomment to test):
-- INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate)
-- VALUES (5, 2, '2026-09-21', '2026-09-23');


-- ============================================================================
-- TASK 6 : STORED PROCEDURE
-- ============================================================================
-- sp_RegisterRental : registers a new rental for a customer/vehicle pair,
-- automatically calculates the rental charge (days * DailyRate), inserts
-- the Rentals row (which fires the triggers above) and inserts the matching
-- Payments row in the same transaction.
-- ============================================================================

DELIMITER $$

CREATE PROCEDURE sp_RegisterRental (
    IN  p_CustomerID        INT,
    IN  p_VehicleID         INT,
    IN  p_RentalDate        DATE,
    IN  p_ExpectedReturnDate DATE,
    IN  p_PaymentMethod     VARCHAR(20),
    OUT p_RentalID          INT,
    OUT p_CalculatedCharge  DECIMAL(10,2)
)
BEGIN
    DECLARE v_DailyRate DECIMAL(10,2);
    DECLARE v_Days      INT;

    -- Fetch the vehicle's daily rate (fails safely if vehicle missing)
    SELECT DailyRate INTO v_DailyRate
    FROM Vehicles
    WHERE VehicleID = p_VehicleID;

    IF v_DailyRate IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid VehicleID.';
    END IF;

    SET v_Days = GREATEST(DATEDIFF(p_ExpectedReturnDate, p_RentalDate), 1);
    SET p_CalculatedCharge = v_Days * v_DailyRate;

    -- Insert rental (trg_rentals_before_insert / after_insert fire here,
    -- enforcing the "no double booking" rule automatically)
    INSERT INTO Rentals (CustomerID, VehicleID, RentalDate, ExpectedReturnDate, TotalAmount)
    VALUES (p_CustomerID, p_VehicleID, p_RentalDate, p_ExpectedReturnDate, p_CalculatedCharge);

    SET p_RentalID = LAST_INSERT_ID();

    INSERT INTO Payments (RentalID, Amount, PaymentDate, PaymentMethod)
    VALUES (p_RentalID, p_CalculatedCharge, p_RentalDate, p_PaymentMethod);

END$$

DELIMITER ;

-- Demonstration / test call: register a new rental for customer 6 (Hina Riaz)
-- on vehicle 4 (KHI-321, currently idle):
CALL sp_RegisterRental(6, 4, '2026-09-20', '2026-09-23', 'Card', @newRentalID, @charge);
SELECT @newRentalID AS NewRentalID, @charge AS CalculatedCharge;

-- Verify: KHI-321 should now show Status = 'Rented'
SELECT VehicleNumber, Status FROM Vehicles WHERE VehicleID = 4;


-- ============================================================================
-- TASK 7 : OPTIMIZATION ANALYSIS (SQL demonstration)
-- ============================================================================
-- See the report for the full written analysis. Summary:
--
-- PROBLEM: Before optimization, Rentals.CustomerID and Rentals.VehicleID had
-- no index, so every JOIN in Task 3 (Q1-Q4) forced a full table scan of
-- Rentals for each row of Customers/Vehicles - fine on 6 rows, but it
-- degrades to O(n*m) as rentals grow into the thousands.
--
-- IMPROVEMENT: composite/foreign-key indexes were added in Task 1
-- (idx_rentals_customer, idx_rentals_vehicle) so the optimizer can use an
-- index lookup/merge instead of a full scan. EXPLAIN below shows the query
-- plan now uses these indexes ("ref"/"eq_ref" type instead of "ALL").
-- ============================================================================
EXPLAIN
SELECT c.FullName, v.VehicleNumber, r.RentalDate
FROM Rentals r
JOIN Customers c ON r.CustomerID = c.CustomerID
JOIN Vehicles  v ON r.VehicleID  = v.VehicleID;

-- ============================================================================
-- END OF FILE
-- ============================================================================
